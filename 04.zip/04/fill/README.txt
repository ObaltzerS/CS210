Author: Oliver Baltzer

All programs should work, althgouh the test for fillstatic seems to not load correctly.
I consulted this slideshpw: https://www.csie.ntu.edu.tw/~cyy/courses/introCS/17fall/lectures/handouts/lec08_HackML.pdf
a few times to help with the syntax. 

