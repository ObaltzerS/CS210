Author: Oliver Baltzer

All chips should work to specification, they passed all the provided tests. 
I implemented an additional chip, Mux8Way, which helped tidy up the JUMP codes in the CPU.
I used the tables provided in chapter 6 to complete this project, and the discussion in class also helped a lot.