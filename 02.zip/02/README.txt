Author: Oliver Baltzer

Citations:

A video by Sebastian Lague titled "How do computers work?". It explained the concepts of adders,
half adders and the ALU really well. Although the implementations in the video were for a 4 bit ALU, I found the explanations really helpful in designing the 16 ALU.
https://youtu.be/QZwneRb-zqA

Notes:

All of the chips should be functional, although they may not be completely optimized. They pass all of the tests supplied in the project files. I didn't create any additional chips or tests for this project. 