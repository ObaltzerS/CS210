Author: Oliver Baltzer, not other contributors

All files should be complete and functional, passing all provided tests

