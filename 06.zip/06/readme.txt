Author: Oliver Baltzer

hasm.py passes all of the symbol and instruction tests, although it cannot compile pong.asm because of a repeated value in the symbol table
I was part way through fixing this issue, but wasnt able to figure it out in time and those parts are now commented out.
I mostly used W3 schools as a reference for Python.